bkg = 0
windows = 0
